﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        Random random = new Random();
        List<PictureBox> balonlar = new List<PictureBox>();
        int skor = 0;
        bool oyunDevamEdiyor = false;

        public Form1()
        {
            InitializeComponent();
            balonlar.Add(pictureBox1);
            balonlar.Add(pictureBox2);
            balonlar.Add(pictureBox3);

            foreach (PictureBox balon in balonlar)
            {
                balon.Visible = false;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            oyunDevamEdiyor = true;
            // Balonları rastgele yerlere ve boyutlarda yerleştir
            foreach (PictureBox balon in balonlar)
            {
                balon.Location = new Point(random.Next(10, this.ClientSize.Width - balon.Width), random.Next(10, this.ClientSize.Height - balon.Height));
                balon.Size = new Size(random.Next(50, 100), random.Next(50, 100));
                balon.Visible = true;
            }

            do
            {
                foreach (PictureBox balon in balonlar)
                {
                    balon.Top += 2; // Balonları 2 piksel aşağı indir
                    if (balon.Top > this.ClientSize.Height)
                    {
                        balon.Top = 0;
                        balon.Left = random.Next(10, this.ClientSize.Width - balon.Width);
                    }
                }

                Application.DoEvents(); // Mesaj kuyruğunu işleyerek diğer olayların işlenmesini sağlar
                System.Threading.Thread.Sleep(20); // 20 milisaniye bekle


            } while (oyunDevamEdiyor);

        }

        private void picturesBox_Click(object sender, EventArgs e)
        {
            PictureBox balon = (PictureBox)sender;
            balon.Visible = false;
            skor++;
            labelSkor.Text = "Skor: " + skor;
        }
    }
}
