namespace görsel_ödevi1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2=new Form2();
            f2.kul_adi = textBox1.Text;
            f2.sifre = textBox2.Text;
            if (f2.kul_adi == "esr" && f2.sifre=="123")
            {
                f2.durum = "giriş başarılı";
            }
            else if (f2.kul_adi != "esr" && f2.sifre == "123")
            {
                f2.durum = "kullanıcı adı yanlış";
            }
            else if(f2.kul_adi != "esr" && f2.sifre != "123")
            {
                f2.durum = "kullanıcı adı ve şifresi yanlış";
            }
            else
            {
                f2.durum = "şifre yanlış";
            }

            f2.Show();
            this.Hide();
        }
    }
}
