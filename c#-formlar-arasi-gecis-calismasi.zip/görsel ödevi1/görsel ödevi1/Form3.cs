﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace görsel_ödevi1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {

            Form4 f4= new Form4();

            int vize=Convert.ToInt32(textBox1.Text);
            int final = Convert.ToInt32(textBox2.Text);
            int ort= Convert.ToInt32(vize * 0.4 + final * 0.6);
          
            if (ort < 50)
            {
                f4.durum = "geçti";
                f4.ort = ort;
                
            }
            else
            {
                f4.durum = "kaldı";
                f4.ort= ort;
            }
         


            f4.Show();
            this.Hide();
        }
    }
}
